package org.basex.query.func;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

/**
 * Java module signature.
 *
 * @author BaseX Team 2005-12, BSD License
 * @author Christian Gruen
 */
@Retention(RetentionPolicy.RUNTIME)
public @interface XQueryFunction {
}
